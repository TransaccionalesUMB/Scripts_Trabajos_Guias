# Transactional System

This project is a Java web application designed for managing a transactional system with secure login functionality and a main requirement form. It utilizes an existing database for user and requirement management.

## Project Structure

```
transactional-system
├── src
│   ├── main
│   │   ├── java
│   │   │   ├── controller
│   │   │   │   ├── LoginServlet.java
│   │   │   │   └── RequirementFormServlet.java
│   │   │   ├── model
│   │   │   │   ├── User.java
│   │   │   │   └── Requirement.java
│   │   │   └── dao
│   │   │       ├── UserDao.java
│   │   │       └── RequirementDao.java
│   │   ├── resources
│   │   │   └── database.properties
│   │   └── webapp
│   │       ├── WEB-INF
│   │       │   ├── web.xml
│   │       │   └── applicationContext.xml
│   │       ├── index.jsp
│   │       ├── login.jsp
│   │       └── requirementForm.jsp
├── pom.xml
└── README.md
```

## Features

- **Secure Login**: Users can log in securely using their credentials.
- **Requirement Management**: Users can submit and manage their requirements through a dedicated form.
- **Database Integration**: The application interacts with a database to store and retrieve user and requirement information.

## Setup Instructions

1. **Clone the Repository**: 
   ```
   git clone <repository-url>
   ```

2. **Navigate to the Project Directory**:
   ```
   cd transactional-system
   ```

3. **Configure Database**: 
   Update the `src/main/resources/database.properties` file with your database connection details.

4. **Build the Project**: 
   Use Maven to build the project:
   ```
   mvn clean install
   ```

5. **Run the Application**: 
   Deploy the application on a servlet container (e.g., Apache Tomcat) and access it via a web browser.

## Usage Guidelines

- Access the application at `http://localhost:8080/transactional-system/`.
- Use the login page to authenticate users.
- After logging in, users can navigate to the requirement form to submit their requirements.

## Contributing

Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.